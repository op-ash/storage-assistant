## Colors

BACKGROUND = "#111315"

SURFACE = "#1B1D20"

SURFACE_LIGHT = "#24272B"

PRIMARY = "#3B82F6"

SUCCESS = "#10B981"

WARNING = "#F59E0B"

ERROR = "#EF4444"

TEXT = "#F3F4F6"

TEXT_SECONDARY = "#9CA3AF"

BORDER = "#2E3136"

## Radius

CARD_RADIUS = 16

BUTTON_RADIUS = 12

INPUT_RADIUS = 10

## Spacing
XS = 6

SM = 10

MD = 16

LG = 24

XL = 32

## Fonts
Segoe UI Variable
Segoe UI

